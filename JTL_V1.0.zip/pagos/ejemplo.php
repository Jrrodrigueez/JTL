<?php
tengo un <li ><a href="detalles.php?id_producto='.$detalles["id_producto"].' &ruta_p='.$detalles["ruta_p"].'&detalles_p='.$detalles["detalles_p"].'">Ver Detalles</a></li>
?>