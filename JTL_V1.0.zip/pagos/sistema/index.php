<?php 
	session_start();
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<?php include "includes/scripts.php"; ?>
	<title>Sisteme Ventas</title>
</head>
<body>
	<?php include "includes/header.php"; ?>
	<section id="container">
		<h1>Bienvenido al sistema</h1>


	</section>
	<?php include "includes/footer.php"; ?>
</body>
</html>